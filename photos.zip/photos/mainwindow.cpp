#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QtGui"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    for(unsigned int i=0; i<15; ++i)
    {
        pic[i] = new QPixmap();
        grayPic[i] = new QPixmap();
        picButton[i] = new QPushButton(this);
        picBrush[i] = new QBrush();
        picPalette[i] = new QPalette();
    }
    createButtons();
    createGrayPics();
    connect(picButton[0], SIGNAL(released()), this, SLOT(picButton0()));
    connect(picButton[1], SIGNAL(released()), this, SLOT(picButton1()));
    connect(picButton[2], SIGNAL(released()), this, SLOT(picButton2()));
    connect(picButton[3], SIGNAL(released()), this, SLOT(picButton3()));
    connect(picButton[4], SIGNAL(released()), this, SLOT(picButton4()));
    connect(picButton[5], SIGNAL(released()), this, SLOT(picButton5()));
    connect(picButton[6], SIGNAL(released()), this, SLOT(picButton6()));
    connect(picButton[7], SIGNAL(released()), this, SLOT(picButton7()));
    connect(picButton[8], SIGNAL(released()), this, SLOT(picButton8()));
    connect(picButton[9], SIGNAL(released()), this, SLOT(picButton9()));
    connect(picButton[10], SIGNAL(released()), this, SLOT(picButton10()));
    connect(picButton[11], SIGNAL(released()), this, SLOT(picButton11()));
    connect(picButton[12], SIGNAL(released()), this, SLOT(picButton12()));
    connect(picButton[13], SIGNAL(released()), this, SLOT(picButton13()));
    connect(picButton[14], SIGNAL(released()), this, SLOT(picButton14()));

}



MainWindow::~MainWindow()
{
    for(unsigned int i=0; i<15; ++i)
    {
        delete pic[i];
        delete grayPic[i];
        delete picButton[i];
        delete picBrush[i];
        delete picPalette[i];
    }
    delete ui;
}
//***************************************************************
void MainWindow::createButtons()
{
    for(unsigned int i=0; i<15; ++i)
    {
        abc = ":pics/car";
        abc.append(QString::number(i));
        abc.append(".jpeg");

       pic[i]->load(abc);
       *pic[i]=pic[i]->scaled(200,150,Qt::IgnoreAspectRatio,Qt::FastTransformation);
    }
    unsigned int a=0;
    if(sizeof(pic)/4%5)
        a=1;

    for(unsigned int j=0; j<sizeof(pic)/4/5 + a; ++j)
        for(unsigned int i=0 ; i<5; ++i)
        {
            if(i==(sizeof(pic)/4%5) && j==sizeof(pic)/4/5)
                break;

            picBrush[i+j*5]->setTexture(*pic[i+j*5]);

            picPalette[i+j*5]->setBrush(QPalette::Button,*(picBrush[i+j*5]));


            picButton[i+j*5]->setFlat(true);
            picButton[i+j*5]->setAutoFillBackground(true);
            picButton[i+j*5]->setPalette(*picPalette[i+j*5]);
            //picButton[i+j*5]->createHeuristicMask();
            picButton[i+j*5]->setGeometry((50+i*250),(50+j*200),(*pic[0]).width(),(*pic[0]).height());
        }
}

/*void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap((50),(50),*pic[0]);
    unsigned int a=0;
    if(sizeof(pic)/4%5)
        a=1;

    for(unsigned int j=0; j<sizeof(pic)/4/5 + a; ++j)
        for(unsigned int i=1 ; i<5; ++i)
        {
            if(i==(sizeof(pic)/4%5) && j==sizeof(pic)/4/5)
                break;
            painter.drawPixmap((50+i*250),(50+j*200),*pic[i+j*5]);
        }
    //painter.setFont(QFont("Times", 35));
    //painter.drawText(rect(),Qt::AlignTop,QString::number(sizeof(pic)));
}*/
//****************************************************************
void MainWindow::makeGray(QPixmap pixmap, int a)
{

    QImage image = pixmap.toImage();
    QRgb col;
    int gray;
    int width = pixmap.width();
    int height = pixmap.height();
    for (int i = 0; i < width; ++i)
    {
        for (int j = 0; j < height; ++j)
        {
            col = image.pixel(i, j);
            gray = qGray(col);
            image.setPixel(i, j, qRgb(gray, gray, gray));
        }
    }
    for(int z = 0; z < width; ++z)
    for (int i = z; i < width; i+=5)
    {
        for (int j = z; j < height; j+=5)
        {
            gray = qGray(0,0,0);
            image.setPixel(i, j, qRgb(gray, gray, gray));
        }
    }
    pixmap = pixmap.fromImage(image);
    *grayPic[a] = pixmap;

}
//*******************************************************************
void MainWindow::createGrayPics()
{
    for(unsigned int i=0; i<15; ++i)
        makeGray(*pic[i], i);
}
//******************************************************************
void MainWindow::picButton0()
{
 if(!isGray[0])
 {
    picBrush[0]->setTexture(*grayPic[0]);
    picPalette[0]->setBrush(QPalette::Button,*(picBrush[0]));
    picButton[0]->setPalette(*picPalette[0]);
    isGray[0]=true;
 }
 else
 {
     picBrush[0]->setTexture(*pic[0]);
     picPalette[0]->setBrush(QPalette::Button,*(picBrush[0]));
     picButton[0]->setPalette(*picPalette[0]);
     isGray[0]=false;
 }

}

void MainWindow::picButton1()
{
 if(!isGray[1])
 {
    picBrush[1]->setTexture(*grayPic[1]);
    picPalette[1]->setBrush(QPalette::Button,*(picBrush[1]));
    picButton[1]->setPalette(*picPalette[1]);
    isGray[1]=true;
 }
 else
 {
     picBrush[1]->setTexture(*pic[1]);
     picPalette[1]->setBrush(QPalette::Button,*(picBrush[1]));
     picButton[1]->setPalette(*picPalette[1]);
     isGray[1]=false;

 }

}
void MainWindow::picButton2()
{
 if(!isGray[2])
 {
    picBrush[2]->setTexture(*grayPic[2]);
    picPalette[2]->setBrush(QPalette::Button,*(picBrush[2]));
    picButton[2]->setPalette(*picPalette[2]);
    isGray[2]=true;
 }
 else
 {
     picBrush[2]->setTexture(*pic[2]);
     picPalette[2]->setBrush(QPalette::Button,*(picBrush[2]));
     picButton[2]->setPalette(*picPalette[2]);
     isGray[2]=false;
 }

}
void MainWindow::picButton3()
{
 if(!isGray[3])
 {
    picBrush[3]->setTexture(*grayPic[3]);
    picPalette[3]->setBrush(QPalette::Button,*(picBrush[3]));
    picButton[3]->setPalette(*picPalette[3]);
    isGray[3]=true;
 }
 else
 {
    picBrush[3]->setTexture(*pic[3]);
    picPalette[3]->setBrush(QPalette::Button,*(picBrush[3]));
    picButton[3]->setPalette(*picPalette[3]);
    isGray[3]=false;
 }
}
void MainWindow::picButton4()
{
 if(!isGray[4])
 {
    picBrush[4]->setTexture(*grayPic[4]);
    picPalette[4]->setBrush(QPalette::Button,*(picBrush[4]));
    picButton[4]->setPalette(*picPalette[4]);
    isGray[4]=true;
 }
 else
 {
     picBrush[4]->setTexture(*pic[4]);
     picPalette[4]->setBrush(QPalette::Button,*(picBrush[4]));
     picButton[4]->setPalette(*picPalette[4]);
     isGray[4]=false;
 }

}
void MainWindow::picButton5()
{
 if(!isGray[5])
 {
    picBrush[5]->setTexture(*grayPic[5]);
    picPalette[5]->setBrush(QPalette::Button,*(picBrush[5]));
    picButton[5]->setPalette(*picPalette[5]);
    isGray[5]=true;
 }
 else
 {
     picBrush[5]->setTexture(*pic[5]);
     picPalette[5]->setBrush(QPalette::Button,*(picBrush[5]));
     picButton[5]->setPalette(*picPalette[5]);
     isGray[5]=false;

 }

}
void MainWindow::picButton6()
{
 if(!isGray[6])
 {
    picBrush[6]->setTexture(*grayPic[6]);
    picPalette[6]->setBrush(QPalette::Button,*(picBrush[6]));
    picButton[6]->setPalette(*picPalette[6]);
    isGray[6]=true;
 }
 else
 {
     picBrush[6]->setTexture(*pic[6]);
     picPalette[6]->setBrush(QPalette::Button,*(picBrush[6]));
     picButton[6]->setPalette(*picPalette[6]);
     isGray[6]=false;
 }

}
void MainWindow::picButton7()
{
 if(!isGray[7])
 {
    picBrush[7]->setTexture(*grayPic[7]);
    picPalette[7]->setBrush(QPalette::Button,*(picBrush[7]));
    picButton[7]->setPalette(*picPalette[7]);
    isGray[7]=true;
 }
 else
 {
     picBrush[7]->setTexture(*pic[7]);
     picPalette[7]->setBrush(QPalette::Button,*(picBrush[7]));
     picButton[7]->setPalette(*picPalette[7]);
     isGray[7]=false;

 }

}
void MainWindow::picButton8()
{
 if(!isGray[8])
 {
    picBrush[8]->setTexture(*grayPic[8]);
    picPalette[8]->setBrush(QPalette::Button,*(picBrush[8]));
    picButton[8]->setPalette(*picPalette[8]);
    isGray[8]=true;
 }
 else
 {
     picBrush[8]->setTexture(*pic[8]);
     picPalette[8]->setBrush(QPalette::Button,*(picBrush[8]));
     picButton[8]->setPalette(*picPalette[8]);
     isGray[8]=false;
 }

}
void MainWindow::picButton9()
{
 if(!isGray[9])
 {
    picBrush[9]->setTexture(*grayPic[9]);
    picPalette[9]->setBrush(QPalette::Button,*(picBrush[9]));
    picButton[9]->setPalette(*picPalette[9]);
    isGray[9]=true;
 }
 else
 {
     picBrush[9]->setTexture(*pic[9]);
     picPalette[9]->setBrush(QPalette::Button,*(picBrush[9]));
     picButton[9]->setPalette(*picPalette[9]);
     isGray[9]=false;
 }

}
void MainWindow::picButton10()
{
 if(!isGray[10])
 {
    picBrush[10]->setTexture(*grayPic[10]);
    picPalette[10]->setBrush(QPalette::Button,*(picBrush[10]));
    picButton[10]->setPalette(*picPalette[10]);
    isGray[10]=true;
 }
 else
 {
     picBrush[10]->setTexture(*pic[10]);
     picPalette[10]->setBrush(QPalette::Button,*(picBrush[10]));
     picButton[10]->setPalette(*picPalette[10]);
     isGray[10]=false;

 }

}
void MainWindow::picButton11()
{
 if(!isGray[11])
 {
    picBrush[11]->setTexture(*grayPic[11]);
    picPalette[11]->setBrush(QPalette::Button,*(picBrush[11]));
    picButton[11]->setPalette(*picPalette[11]);
    isGray[11]=true;
 }
 else
 {
    picBrush[11]->setTexture(*pic[11]);
    picPalette[11]->setBrush(QPalette::Button,*(picBrush[11]));
    picButton[11]->setPalette(*picPalette[11]);
    isGray[11]=false;
 }

}
void MainWindow::picButton12()
{
 if(!isGray[12])
 {
     picBrush[12]->setTexture(*grayPic[12]);
     picPalette[12]->setBrush(QPalette::Button,*(picBrush[12]));
     picButton[12]->setPalette(*picPalette[12]);
     isGray[12]=true;
 }
 else
 {
     picBrush[12]->setTexture(*pic[12]);
     picPalette[12]->setBrush(QPalette::Button,*(picBrush[12]));
     picButton[12]->setPalette(*picPalette[12]);
     isGray[12]=false;
 }
}
void MainWindow::picButton13()
{
 if(!isGray[13])
 {
    picBrush[13]->setTexture(*grayPic[13]);
    picPalette[13]->setBrush(QPalette::Button,*(picBrush[13]));
    picButton[13]->setPalette(*picPalette[13]);
    isGray[13]=true;
 }
 else
 {
    picBrush[13]->setTexture(*pic[13]);
    picPalette[13]->setBrush(QPalette::Button,*(picBrush[13]));
    picButton[13]->setPalette(*picPalette[13]);
    isGray[13]=false;
 }

}
void MainWindow::picButton14()
{
 if(!isGray[14])
 {
    picBrush[14]->setTexture(*grayPic[14]);
    picPalette[14]->setBrush(QPalette::Button,*(picBrush[14]));
    picButton[14]->setPalette(*picPalette[14]);
    isGray[14]=true;
 }
 else
 {
    picBrush[14]->setTexture(*pic[14]);
    picPalette[14]->setBrush(QPalette::Button,*(picBrush[14]));
    picButton[14]->setPalette(*picPalette[14]);
    isGray[14]=false;
 }

}
